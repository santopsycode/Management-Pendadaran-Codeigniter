<?php

	include 'koneksi.php';

	$nim = $_GET['nim'];

	$query 		= mysqli_query($koneksi, "select * from mhs where nim='$nim'");
	$pelanggan 	= mysqli_fetch_array($query);
	$data 		= array(
	            'nama' => $pelanggan['nama']);
	 echo json_encode($data);
	 
?>
