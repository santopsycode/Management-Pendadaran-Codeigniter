<?php 

  include 'database.php';
  $db = new database();

 ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>ADMIN TUBES IMK - PKPL</title>

    <!-- Bootstrap core CSS -->
    <link href="../../assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Style core CSS -->
    <link href="../../assets/css/style.css" rel="stylesheet">
    <link href="../../assets/css/bootstrap-table.css" rel="stylesheet">
    <link href="../../assets/css/bootstrap-datetimepicker.css" rel="stylesheet">
    <link href="../../assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="../../assets/css/font-awesome-animation.css" rel="stylesheet">

    
    <script src="../../assets/js/moment-with-locales.js"></script>
    <script src="../../assets/js/jquery-2.1.1.min.js"></script>
  </head>

  <body style="background-color: #eee">


  <div class="head">
    <a href="#"><strong>TUBES</strong></a>
  </div>

    <!-- Fixed Navbar -->
    <nav class="navbar navbar-default navbar-fixed-top" style="margin-left: 228px">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#"><span class="glyphicon glyphicon-education" style="display:inline-block; position:relative; padding: 8px; margin-bottom: 40px; -moz-border-radius:50%; -webkit-border-radius:50%; border-radius:50%; text-align:center; width: 35px; height: 35px; font-size:20px; background-color: #e25f5f; color: #2a3f54; top: -8px; left: -33px;"></span></a>
        </div>
        <div id="navbar" class="navbar-right navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                <span>Herman Yuliansyah, S.T., M. Eng</span>
              </a>
              <ul class="dropdown-menu">
                <li><a href="http://localhost/tubes/admin/index.php/home/logout"><span>LOGOUT</span></a></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  <!-- /Fixed Navbar -->

  <!-- Fixed Sidebar -->
    <div id="sidebar" class="col-sm-2 sidebar">
      <ul class="nav menu">
      <li>
        <img src="../assets/img/about1.jpg" class="img-circle center-block" style="margin-top: 10px; margin-bottom: 10px; height: 70px; width: 70px;">
        <p class="text-center" style="color: white;">Welcome</p>
        <p class="text-center" style="color: #e25f5f;">Herman Yuliansyah, S.T., M. Eng</p>
      </li>
      <li class="parent">
        <p class="text-center">MAIN NAVIGATION</p>
      </li>
        <li class="parent">
          <a href="http://localhost/tubes/admin/index.php/home"><span class="glyphicon glyphicon-home"></span> Dashboard</a>
        </li>
        <li class="parent active">
          <a data-toggle="collapse" href="#sub-item-1"><span class="glyphicon glyphicon-book"></span> Pendadaran</a>
          <ul class="children collapse" id="sub-item-1">
            <li>
              <a class="" href="http://localhost/tubes/admin/pendadaran/"> <span class="glyphicon glyphicon-user"></span> Peserta Pendadaran</a>
            </li>
          </ul>
        </li>
        <li class="parent">
          <a data-toggle="collapse" href="#sub-item-2"><span class="glyphicon glyphicon-book"></span> Nilai</a>
          <ul class="children collapse" id="sub-item-2">
            <li>
              <a class="" href="http://localhost/tubes/admin/index.php/home/penguji1"><span class="glyphicon glyphicon-paperclip"></span> Penguji 1</a>
            </li>
            <li>
              <a class="" href="http://localhost/tubes/admin/index.php/home/penguji2"><span class="glyphicon glyphicon-paperclip"></span> Penguji 2</a>
            </li>
            <li>
              <a class="" href="http://localhost/tubes/admin/index.php/home/pembimbing"><span class="glyphicon glyphicon-paperclip"></span> Pembimbing</a>
            </li>
            <li>
              <a class="" href="http://localhost/tubes/admin/index.php/home/nilai_akhir"><span class="glyphicon glyphicon-paperclip"></span> Nilai Akhir</a>
            </li>
          </ul>
        </li>
      </ul>
    </div>
  <!-- Fixed Sidebar -->

  <!-- Main Section -->
    <div class="col-sm-10 col-sm-offset-2 main">

      <ol class="breadcrumb">
      	<li>
      		<a href="http://localhost/tubes/admin/index.php/home">Dashboard</a>
      	</li>
      	<li>
      		<a href="http://localhost/tubes/admin/pendadaran/">Pendadaran</a>
      	</li>
      	<li class="active">Form Pendafaran</li>
      </ol>

      <div class="container-fluid">
        <div class="row">

          <!-- Content Session -->
            
            <div class="col-md-6">
              <div class="newpan">
                <div class="panel-heading">
                  <h3 class="panel-title">Form Pendaftaran Pendadaan Teknik Informaika</h3>
                </div>
                <div class="panel-body">
                <br><br>
                  <form action="proses.php?aksi=tambah" method="POST" role="form">

                      <div class="col-md-12">
                         <label for="firstname" class="col-md-4">Nim:</label>
                          <div class="col-md-8">
                              <input type="text" onkeyup="isi_mhs()" name="nim" id="nim" class="form-control"  required ><br>
                          </div><br>
                      </div>

                      <div class="col-md-12">
                          <label for="firstname" class="col-md-4">Nama:</label>
                          <div class="col-md-8">
                              <input type="text" name="nama" id="nama" class="form-control" required readonly><br>
                          </div>
                      </div>
                      <div class="col-md-12">
                          <label for="firstname" class="col-md-4">Judul Skripsi:</label>
                          <div class="col-md-8">
                              <input rows="3" type="text" name="judul_skripsi" id="judul_skripsi" class="form-control" required><br>
                          </div>
                      </div>
                      <div class="col-md-12">
                          <label for="firstname" class="col-md-4">Tanggal Pendadaran:</label>
                          <div class="col-md-8">
                            <div class='input-group date' id='date'>
                                    <input type='text' name="tanggal_pendadaran" id="tanggal_pendadaran" class="form-control" value="" required>
                                    <span class="input-group-addon">
                                        <span class="glyphicon glyphicon-calendar"></span>
                                    </span>
                                </div><br>
                          </div>
                      </div>
                      <div class="col-md-12">
                      <label for="firstname" class="col-md-4">Dosen Pembimbing:</label>
                      <div class="col-md-8">
                        <select id="dosen_pembimbing" name="dosen_pembimbing" type="text" class="form-control" required="required" onchange="isi_pembimbing()" >
                          <option value="">-- Pilih Satu --</option>
                          <?php 
                            foreach ($db->tampil_dosen() as $row){
                            ?>
                          <option value="<?php echo $row['nama']; ?>" ><?php echo $row['nama']; ?></option>
                          <?php } ?>
                        </select><br>
                        <input rows="3" type="hidden" name="niy_pembimbing" id="niy_pembimbing" class="form-control" value="" placeholder="harusnya otomatis" required readonly>
                      </div><br>
                    </div>
                      <div class="col-md-12">
                      <label for="firstname" class="col-md-4">Dosen Penguji 1:</label>
                      <div class="col-md-8">
                        <select id="dosen_penguji1" name="dosen_penguji1" type="text" class="form-control" required="required" onchange="isi_penguji1()" >
                          <option value="">-- Pilih Satu --</option>
                          <?php 
                            foreach ($db->tampil_dosen() as $row){
                            ?>
                          <option value="<?php echo $row['nama']; ?>" ><?php echo $row['nama']; ?></option>
                          <?php } ?>
                        </select><br>
                      </div><br>
                      <input rows="3" type="hidden" name="niy_penguji1" id="niy_penguji1" class="form-control" value="" placeholder="harusnya otomatis" required readonly>
                    </div>
                      <div class="col-md-12">
                        <label for="firstname" class="col-md-4">Dosen Penguji 2:</label>
                        <div class="col-md-8">
                          <select id="dosen_penguji2" name="dosen_penguji2" type="text" class="form-control" required="required" onchange="isi_penguji2()" >
                          <option value="">-- Pilih Satu --</option>
                            <?php 
                              foreach ($db->tampil_dosen() as $row){
                              ?>
                            <option value="<?php echo $row['nama']; ?>" ><?php echo $row['nama']; ?></option>
                            <?php } ?>
                          </select><br>
                        </div><br>
                        <input rows="3" type="hidden" name="niy_penguji2" id="niy_penguji2" class="form-control" value="" placeholder="harusnya otomatis" required readonly>
                      </div>
                      <div class="col-md-12">
                          <label for="firstname" class="col-md-4">Tempat Ujian:</label>
                          <div class="col-md-8">
                              <select id="tempat_ujian" name="tempat_ujian" type="text" class="form-control" value="">
                              <option value="">-- Pilih Ruang --</option>
                              <option value="Ruang Prodi">Ruang Prodi</option>
                              <option value="Lab Lantai 2">Lab Lantai 2</option>
                              <option value="Auditorium">Auditorium</option>
                              </select><br>
                          </div><br>
                      </div>

                    <div class="col-md-12">
                      <div class="col-md-4">
                        <button class="btn btn-block btn-default" type="submit">SIMPAN</button>
                      </div>
                      </div>
                    </form>

                    <script type="text/javascript">
                        function isi_mhs(){
                              var nim = $("#nim").val();
                              $.ajax({
                                  url: 'isi_mhs.php',
                                  data:"nim="+nim ,
                              }).success(function (data) {
                                  var json = data,
                                  obj = JSON.parse(json);
                                  $('#nama').val(obj.nama);
                              });
                        }


                        function isi_penguji1(){
                              var dosen_penguji1 = $("#dosen_penguji1").val();
                              $.ajax({
                                  url: 'isi_penguji1.php',
                                  data:"dosen_penguji1="+dosen_penguji1 ,
                              }).success(function (data) {
                                  var json = data,
                                  obj = JSON.parse(json);
                                  $('#niy_penguji1').val(obj.niy_penguji1);
                              });
                        }

                        function isi_penguji2(){
                              var dosen_penguji2 = $("#dosen_penguji2").val();
                              $.ajax({
                                  url: 'isi_penguji2.php',
                                  data:"dosen_penguji2="+dosen_penguji2 ,
                              }).success(function (data) {
                                  var json = data,
                                  obj = JSON.parse(json);
                                  $('#niy_penguji2').val(obj.niy_penguji2);
                              });
                        }

                        function isi_pembimbing(){
                              var dosen_pembimbing = $("#dosen_pembimbing").val();
                              $.ajax({
                                  url: 'isi_pembimbing.php',
                                  data:"dosen_pembimbing="+dosen_pembimbing ,
                              }).success(function (data) {
                                  var json = data,
                                  obj = JSON.parse(json);
                                  $('#niy_pembimbing').val(obj.niy_pembimbing);
                              });
                        }
                    </script>

                </div>
              </div>   
            </div>


              <script type="text/javascript">
                        $(function () {
                            var date1 = new Date();
                                date1.setDate(date1.getDate()+1);
                            var date2 = new Date();
                                date2.setDate(date2.getDate()+2);
                            var date3 = new Date();
                                date3.setDate(date3.getDate()+3);
                            var date4 = new Date();
                                date4.setDate(date4.getDate()+4);
                            var date5 = new Date();
                                date5.setDate(date5.getDate()+5);
                            var date6 = new Date();
                                date6.setDate(date6.getDate()+6);
                            var date7 = new Date();
                                date7.setDate(date7.getDate()+7);
                            var date8 = new Date();
                                date8.setDate(date8.getDate()+8);

                            $('#date').datetimepicker({
                                defaultDate: date8,
                                format: 'YYYY-MM-DD hh:mm',
                                disabledDates:[new Date(),
                                            date1,
                                            date2,
                                            date3,
                                            date4,
                                            date5,
                                            date6,
                                            date7
                                            ]
                            });
                        });
                    </script>
          <!-- /Content Session -->

       </div>
      </div>
      
        <footer class="footer">
            <div class="container-fluid">
              <div class="pull-right hidden-xs">
              <b>Version</b> 2.1.12
            </div>
            <strong>Copyright © 2016 <a href="#">Psycode</a>. </strong> All rights reserved.
            </div>
        </footer>
    </div>


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="../../assets/js/bootstrap.min.js"></script>
    <script src="../../assets/js/bootstrap-datetimepicker.js"></script>
    <script src="../../assets/js/bootstrap-table.js"></script>
  </body>
</html>
