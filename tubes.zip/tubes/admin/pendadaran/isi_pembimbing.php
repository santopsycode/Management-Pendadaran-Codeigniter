<?php

	include 'koneksi.php';

	$dosen_pembimbing = $_GET['dosen_pembimbing'];

	$query 		= mysqli_query($koneksi, "select * from dosen where nama='$dosen_pembimbing'");
	$hasil 		= mysqli_fetch_array($query);
	$data 		= array(
	            'niy_pembimbing' => $hasil['niy']);
	 echo json_encode($data);
	 
?>
