<?php

	include 'koneksi.php';

	$dosen_penguji1 = $_GET['dosen_penguji1'];

	$query 		= mysqli_query($koneksi, "select * from dosen where nama='$dosen_penguji1'");
	$hasil 		= mysqli_fetch_array($query);
	$data 		= array(
	            'niy_penguji1' => $hasil['niy']);
	 echo json_encode($data);
	 
?>
