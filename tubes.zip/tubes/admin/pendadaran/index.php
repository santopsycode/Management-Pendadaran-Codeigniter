<?php 

  include 'database.php';
  $db = new database();

 ?>

<!DOCTYPE html>
<html lang="en">
  <head>
    <meta charset="utf-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <!-- The above 3 meta tags *must* come first in the head; any other head content must come *after* these tags -->
    <meta name="description" content="">
    <meta name="author" content="">
    <link rel="icon" href="../../favicon.ico">

    <title>ADMIN TUBES IMK - PKPL</title>

    <!-- Bootstrap core CSS -->
    <link href="../../assets/css/bootstrap.min.css" rel="stylesheet">

    <!-- Style core CSS -->
    <link href="../../assets/css/style.css" rel="stylesheet">
    <link href="../../assets/css/bootstrap-table.css" rel="stylesheet">
    <link href="../../assets/css/bootstrap-datetimepicker.css" rel="stylesheet">
    <link href="../../assets/css/font-awesome.min.css" rel="stylesheet">
    <link href="../../assets/css/font-awesome-animation.css" rel="stylesheet">

    
    <script src="../../assets/js/moment-with-locales.js"></script>
    <script src="../../assets/js/jquery-2.1.1.min.js"></script>
  </head>

  <body style="background-color: #eee">


  <div class="head">
    <a href="#"><strong>TUBES</strong></a>
  </div>

    <!-- Fixed Navbar -->
    <nav class="navbar navbar-default navbar-fixed-top" style="margin-left: 228px">
      <div class="container-fluid">
        <div class="navbar-header">
          <button type="button" class="navbar-toggle collapsed" data-toggle="collapse" data-target="#sidebar" aria-expanded="false" aria-controls="navbar">
            <span class="sr-only">Toggle navigation</span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
            <span class="icon-bar"></span>
          </button>
          <a class="navbar-brand" href="#"><span class="glyphicon glyphicon-education" style="display:inline-block; position:relative; padding: 8px; margin-bottom: 40px; -moz-border-radius:50%; -webkit-border-radius:50%; border-radius:50%; text-align:center; width: 35px; height: 35px; font-size:20px; background-color: #e25f5f; color: #2a3f54; top: -8px; left: -33px;"></span></a>
        </div>
        <div id="navbar" class="navbar-right navbar-collapse collapse">
          <ul class="nav navbar-nav">
            <li class="dropdown">
              <a href="#" class="dropdown-toggle" data-toggle="dropdown" role="button" aria-haspopup="true" aria-expanded="false">
                <span>Herman Yuliansyah, S.T., M. Eng</span>
              </a>
              <ul class="dropdown-menu">
                <li><a href="http://localhost/tubes/admin/index.php/home/logout"><span>LOGOUT</span></a></li>
              </ul>
            </li>
          </ul>
        </div>
      </div>
    </nav>
  <!-- /Fixed Navbar -->

  <!-- Fixed Sidebar -->
    <div id="sidebar" class="col-sm-2 sidebar">
      <ul class="nav menu">
      <li>
        <img src="../assets/img/about1.jpg" class="img-circle center-block" style="margin-top: 10px; margin-bottom: 10px; height: 70px; width: 70px;">
        <p class="text-center" style="color: white;">Welcome</p>
        <p class="text-center" style="color: #e25f5f;">Herman Yuliansyah, S.T., M. Eng</p>
      </li>
      <li class="parent">
        <p class="text-center">MAIN NAVIGATION</p>
      </li>
      <li class="parent">
          <a href="http://localhost/tubes/admin/index.php/home"><span class="glyphicon glyphicon-home"></span> Dashboard</a>
        </li>
        <li class="parent active">
          <a data-toggle="collapse" href="#sub-item-1"><span class="glyphicon glyphicon-book"></span> Pendadaran</a>
          <ul class="children collapse" id="sub-item-1">
            <li>
              <a class="" href="http://localhost/tubes/admin/pendadaran/"> <span class="glyphicon glyphicon-user"></span> Peserta Pendadaran</a>
            </li>
          </ul>
        </li>
        <li class="parent">
          <a data-toggle="collapse" href="#sub-item-2"><span class="glyphicon glyphicon-book"></span> Nilai</a>
          <ul class="children collapse" id="sub-item-2">
            <li>
              <a class="" href="http://localhost/tubes/admin/index.php/home/penguji1"><span class="glyphicon glyphicon-paperclip"></span> Penguji 1</a>
            </li>
            <li>
              <a class="" href="http://localhost/tubes/admin/index.php/home/penguji2"><span class="glyphicon glyphicon-paperclip"></span> Penguji 2</a>
            </li>
            <li>
              <a class="" href="http://localhost/tubes/admin/index.php/home/pembimbing"><span class="glyphicon glyphicon-paperclip"></span> Pembimbing</a>
            </li>
            <li>
              <a class="" href="http://localhost/tubes/admin/index.php/home/nilai_akhir"><span class="glyphicon glyphicon-paperclip"></span> Nilai Akhir</a>
            </li>
          </ul>
        </li>
      </ul>
    </div>
  <!-- Fixed Sidebar -->

  <!-- Main Section -->
    <div class="col-sm-10 col-sm-offset-2 main">

      <ol class="breadcrumb">
      	<li>
      		<a href="http://localhost/tubes/admin/index.php/home"><span class="glyphicon glyphicon-home"></span> Dashboard</a>
      	</li>
      	<li class="active">Pendafaran</li>
      </ol>

      <div class="container-fluid">
        <div class="row">

          <!-- Content Session -->
            
            <div class="newpan">
              <div class="panel-heading">
                  <h3 class="panel-title">Tabel Peserta Ujian Pendadaran</h3>
              </div>
              <div class="panel-body">
                  <div class="row">
                      <div class="col-lg-12">
                          <div>
                              <div class="panel-body">
                                  <a href="input-pendadaran.php" class="btn btn-default">Tambah Data</a>
                                  <table data-toggle="table" data-url="tables/data1.json"  data-show-refresh="false" data-show-toggle="true" data-show-columns="true" data-search="true" data-select-item-name="toolbar1" data-pagination="true" data-sort-name="name" data-sort-order="desc" class="table table-bordered">
                                      <thead  style="background-color: #f1f1f1">
                                          <tr>
                                              <th data-field="nim" data-sortable="true">Nim</th>
                                              <th data-field="nama" data-sortable="true">Nama</th>
                                              <th data-field="judul_skripsi" data-sortable="true">Judul Skripsi</th>
                                              <th data-field="tanggal_pendadaran" data-sortable="true">Tanggal Ujian</th>
                                              <th data-field="dosen_pembimbing" data-sortable="true">dosen Pembimbing</th>
                                              <th data-field="dosen_penguji1" data-sortable="true">Dosen Penguji 1</th>
                                              <th data-field="dosen_penguji2" data-sortable="true">Dosen Penguji 2</th>
                                              <th data-field="tempat_ujian" data-sortable="true">Tempat Ujian</th>
                                              <th data-field="aksi" data-sortable="true">Aksi</th>
                                          </tr>
                                      </thead>
                                          
                                      <tbody>
                                          <tr class="odd gradeX">
                                              <?php 
                                                foreach ($db->tampilData() as $row){
                                              ?>
                                              <td><?php echo $row['nim']; ?></td>
                                              <td><?php echo $row['nama']; ?></td>
                                              <td><?php echo $row['judul_skripsi']; ?></td>
                                              <td><?php echo $row['tanggal_pendadaran']; ?></td>
                                              <td><?php echo $row['dosen_pembimbing']; ?></td>
                                              <td><?php echo $row['dosen_penguji1']; ?></td>
                                              <td><?php echo $row['dosen_penguji2']; ?></td>
                                              <td><?php echo $row['tempat_ujian']; ?></td>
                                              <td>
                                                  <div class="btn-group">
                                                    <a class="btn btn-success" href="edit_pendadaran.php?nim=<?php echo $row['nim']; ?>&aksi=edit"><span class="glyphicon glyphicon-pencil"></span></a>
                                                    <a class="btn btn-default" href="proses.php?nim=<?php echo $row['nim']; ?>&aksi=hapus" onclick="return confirm('anda yakin ?');"><span class=" glyphicon glyphicon-trash"></span></a>
                                                  </div>
                                                  
                                                  
                                              </td>
                                          </tr>
                                          <?php }?>
                                      </tbody>
                                  </table>
                                              
                                  <script>
                                      $(function () {
                                          $('#hover, #striped, #condensed').click(function () {
                                              var classes = 'table';
                                              
                                                  if ($('#hover').prop('checked')) {
                                                      classes += ' table-hover';
                                                  }
                                                  if ($('#condensed').prop('checked')) {
                                                      classes += ' table-condensed';
                                                  }
                                                  $('#table-style').bootstrapTable('destroy')
                                                      .bootstrapTable({
                                                          classes: classes,
                                                          striped: $('#striped').prop('checked')
                                                  });
                                          });
                                      });
                                              
                                      function rowStyle(row, index) {
                                          var classes = ['active', 'success', 'info', 'warning', 'danger'];
                                              
                                              if (index % 2 === 0 && index / 2 < classes.length) {
                                                  return {
                                                      classes: classes[index / 2]
                                                  };
                                              }
                                              return {};
                                          }
                                  </script>
                              </div>
                          </div>
                      </div>
                  </div>
              </div>
          </div>
          <br><br><br><br><br><br>

          <!-- /Content Session -->

        </div>
      </div>
        <footer class="footer">
            <div class="container-fluid">
              <div class="pull-right hidden-xs">
              <b>Version</b> 2.1.12
            </div>
            <strong>Copyright © 2016 <a href="#">Psycode</a>. </strong> All rights reserved.
            </div>
        </footer>
    </div>
  <!-- Main Section -->


    <!-- Bootstrap core JavaScript
    ================================================== -->
    <!-- Placed at the end of the document so the pages load faster -->
    <script src="../../assets/js/bootstrap.min.js"></script>
    <script src="../../assets/js/bootstrap-datetimepicker.js"></script>
    <script src="../../assets/js/bootstrap-table.js"></script>
  </body>
</html>
