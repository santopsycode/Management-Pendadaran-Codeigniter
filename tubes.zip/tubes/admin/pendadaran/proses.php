<?php 

	include 'database.php';
	$db = new database();

	$aksi = $_GET['aksi'];
	if ($aksi == "tambah") {
		
		$db->input(	$_POST['nim'], 
					$_POST['nama'], 
					$_POST['judul_skripsi'], 
					$_POST['tanggal_pendadaran'], 
					$_POST['dosen_pembimbing'], 
					$_POST['niy_pembimbing'], 
					$_POST['dosen_penguji1'], 
					$_POST['niy_penguji1'], 
					$_POST['dosen_penguji2'], 
					$_POST['niy_penguji2'], 
					$_POST['tempat_ujian']
					);
		header("location:http://localhost/tubes/admin/pendadaran/");

	} elseif ($aksi == "hapus") {

		$db->hapus($_GET['nim']);
		header("location:http://localhost/tubes/admin/pendadaran/");

	} elseif ($aksi == "update") {

		$db->update($_POST['nim'], 
					$_POST['nama'], 
					$_POST['judul_skripsi'], 
					$_POST['tanggal_pendadaran'], 
					$_POST['dosen_pembimbing'], 
					$_POST['niy_pembimbing'], 
					$_POST['dosen_penguji1'], 
					$_POST['niy_penguji1'], 
					$_POST['dosen_penguji2'], 
					$_POST['niy_penguji2'], 
					$_POST['tempat_ujian']
					);
		header("location:http://localhost/tubes/admin/pendadaran/");
	}

 ?>
