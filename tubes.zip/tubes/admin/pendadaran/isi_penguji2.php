<?php

	include 'koneksi.php';

	$dosen_penguji2 = $_GET['dosen_penguji2'];

	$query 		= mysqli_query($koneksi, "select * from dosen where nama='$dosen_penguji2'");
	$hasil 		= mysqli_fetch_array($query);
	$data 		= array(
	            'niy_penguji2' => $hasil['niy']);
	 echo json_encode($data);
	 
?>
