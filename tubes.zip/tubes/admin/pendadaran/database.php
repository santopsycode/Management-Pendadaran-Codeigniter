<?php 

	class Database
	{
		var $host		= "localhost";
		var $username	= "root";
		var $password	= "";
		var $db 		= "db_tubes";

		function __construct()
		{
			mysql_connect($this->host, $this->username, $this->password);
			mysql_select_db($this->db);
		}

		public function tampilData()
		{
			$data = mysql_query("SELECT * FROM pendadaran");
			while ($d =mysql_fetch_array($data)){
				$hasil[] = $d;
			}
			return $hasil;
		}

		/*
		*
		*
		*
		Fungsi utuk mengambil niy dosen dari tabel dosen ke form pendaftaran pendadaran
		*/
		public function tampil_dosen()
		{
			$data = mysql_query("SELECT * FROM dosen");
			while ($d =mysql_fetch_array($data)){
				$hasil[] = $d;
			}
			return $hasil;
		}

		public function tampil_mhs()			//menampilkan nama mhs
		{
			$data = mysql_query("SELECT * FROM mhs");
			while ($d =mysql_fetch_array($data)){
				$hasil[] = $d;
			}
			return $hasil;
		}

		//fungsi menginputkan penjadwalan pendadaran
		public function input($nim, $nama, $judul_skripsi, $tanggal_pendadaran, $dosen_pembimbing, $niy_pembimbing, $dosen_penguji1, $niy_penguji1, $dosen_penguji2, $niy_penguji2, $tempat_ujian)
		{
			mysql_query("INSERT INTO pendadaran VALUES('$nim','$nama','$judul_skripsi','$tanggal_pendadaran','$dosen_pembimbing','$niy_pembimbing','$dosen_penguji1','$niy_penguji1','$dosen_penguji2','$niy_penguji2','$tempat_ujian','','','','','','','','','','','','','','','','','','')");
		}

		//fungsi menghapus penjadwalan pendadaran
		public function hapus($nim)
		{
			mysql_query("DELETE FROM pendadaran WHERE nim='$nim'");
		}

		//fungsi mengedit penjadwalan pendadaran
		public function edit($nim)
		{
			$data = mysql_query("SELECT * FROM pendadaran WHERE nim='$nim'");
			while ($d = mysql_fetch_array($data)){
				$hasil[] = $d;
			}
			return $hasil;
		}

		//fungsi mengupdate penjadwalan pendadaran
		public function update($nim, $nama, $judul_skripsi, $tanggal_pendadaran, $dosen_pembimbing, $niy_pembimbing, $dosen_penguji1, $niy_penguji1, $dosen_penguji2, $niy_penguji2, $tempat_ujian)
		{
			mysql_query("UPDATE pendadaran SET judul_skripsi='$judul_skripsi', tanggal_pendadaran='$tanggal_pendadaran', dosen_pembimbing='$dosen_pembimbing', niy_pembimbing='$niy_pembimbing', dosen_penguji1='$dosen_penguji1', niy_penguji1='$niy_penguji1', dosen_penguji2='$dosen_penguji2', niy_penguji2='$niy_penguji2', tempat_ujian='$tempat_ujian'  WHERE nim='$nim'");
		}

	}

 ?>
