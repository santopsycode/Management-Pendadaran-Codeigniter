insert into `tb_kotaindonesia` (`id`, `nama_kota`, `ibu_kota`, `keterangan`) values('1','Medan','Medan','Kota medan adalah ibukota Provinsi Sumatera Utara');
insert into `tb_kotaindonesia` (`id`, `nama_kota`, `ibu_kota`, `keterangan`) values('2','Tapanuli Utara','Tarutung','Tapanuli Utara atau sering disebut TAPUT adalah sebuah tempat sejuk');
insert into `tb_kotaindonesia` (`id`, `nama_kota`, `ibu_kota`, `keterangan`) values('3','Jakarta','Jakarta','Jakarta Megapolitan Ibukota Negara Republik Indonesia');
insert into `tb_kotaindonesia` (`id`, `nama_kota`, `ibu_kota`, `keterangan`) values('4','Padang','Padang','Padang adalah tempat wisata jam gadang, disana terdapat jembatan yang membelah sungai musi');
insert into `tb_kotaindonesia` (`id`, `nama_kota`, `ibu_kota`, `keterangan`) values('5','Deliserdang','Lubuk Pakam','Sebuah kota sebelum medan yang kita pijak pertama sekali jika lewat udara (Bandara Kualanamu).');
