-- phpMyAdmin SQL Dump
-- version 4.5.1
-- http://www.phpmyadmin.net
--
-- Host: 127.0.0.1
-- Generation Time: 14 Nov 2016 pada 18.52
-- Versi Server: 10.1.16-MariaDB
-- PHP Version: 5.6.24

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `db_tubes`
--

-- --------------------------------------------------------

--
-- Struktur dari tabel `dosen`
--

CREATE TABLE `dosen` (
  `niy` varchar(15) NOT NULL,
  `nama` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `dosen`
--

INSERT INTO `dosen` (`niy`, `nama`) VALUES
('0006027001', 'Eko Aribowo, S.T., M.Kom'),
('0014107301', 'Ali Tarmuji, S.T., M. Cs'),
('0015118001', 'Fiftin Noviyanto, S.T., M. Cs'),
('0017107601', 'Farida Sulistyorini, S.T.'),
('0019087601', 'Nur Rochmah Dyah Pujiastuti, S.T, M.Kom.'),
('0507087202', 'Rusydi Umar, S.T., M.T, Ph.D.'),
('0512078304', 'Herman Yuliansyah, S.T., M. Eng'),
('060150841', 'Adhi Prahara, S.Si., M.Cs.'),
('060150842', 'Dewi Pramudi Ismi, S.T., M.CompSc'),
('60010308', 'Sri Handayaningsih, S.T., M.T.'),
('60010314', 'Taufik Ismail, S.T., M. Cs'),
('60020388', 'Sri Winiarti, S.T., M. Cs'),
('60030475', 'Drs. Tedy Setiadi, M.T'),
('60030476', 'Ardiansyah, S.T., M. Cs'),
('60030479', 'Muhammad Aziz, S.T., M. Cs'),
('60030480', 'Ir. Ardi Pujiyanta, M. T.'),
('60040496', 'Murinto, S.Si., M. Kom'),
('60040497', 'Dewi Soyusiawaty, S.T., M.T'),
('60090586', 'Arfiani Nur Khusna, S.T., M.Kom.'),
('60090587', 'Lisna Zahrotun S.T.'),
('60110647', 'Anna Hendri Soleliza Jones, S. Kom'),
('60130756', 'Yana Hendriana, S.T., M.Eng.'),
('60130757', 'Andri Pranolo, S.Kom., M. Cs'),
('60160863', 'Ahmad Azhari, S.Kom., M.Eng.'),
('60160865', 'Widhia Oktoeberza KZ., S.T., M.Eng.'),
('60160952', 'Supriyanto, S.T., M.T.'),
('60160978', 'Dwi Normawati, S.T., M.Eng.'),
('60160979', 'Jefree Fahana, ST., M.Kom.'),
('60160980', 'Nuril Anwar, S.T.,M.Kom'),
('60910095', 'Drs. Wahyu Pujiyono, M. Kom'),
('60960147', 'Mushlihudin, S.T., M.T.');

-- --------------------------------------------------------

--
-- Struktur dari tabel `mhs`
--

CREATE TABLE `mhs` (
  `nim` int(11) NOT NULL,
  `nama` varchar(50) DEFAULT NULL,
  `prodi` varchar(50) DEFAULT NULL,
  `fakultas` varchar(50) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `mhs`
--

INSERT INTO `mhs` (`nim`, `nama`, `prodi`, `fakultas`) VALUES
(1300018015, 'Harbiyana Uyun Maruf', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018001, 'Oktaviyanto Rizal Chang', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018003, 'Aji Puwariyanto', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018004, 'Dimas Wahyu Pribadi', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018005, 'Herwin Wibowo', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018006, 'Syaripudin Khairil Anwar', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018008, 'Arimby Kusuma Wardani', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018009, 'Tri Susanto Saputro', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018012, 'Mackands Leonardo Oktano', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018014, 'Dian Hafsari', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018016, 'Muhammad Rasyid Ridho', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018017, 'Dedy Saputra', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018019, 'Jundy Islami', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018021, 'Candra Ariwiyanto', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018023, 'Wahyu Ardianto', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018024, 'Ifansjah Putra', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018025, 'Windy Shela Ramadhani', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018026, 'Farradz Agam Alhammidana', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018029, 'Nandatama Eda Pradana', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018031, 'Sendy Yulianto', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018032, 'Adi Romansa', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018033, 'Amirul Putra Justicia', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018035, 'Ibnu Sulistiyo', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018036, 'Tegar Putra Kurniawan', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018038, 'Siti Soia Rani', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018040, 'Muhammad Arip', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018041, 'Nita Hildayanti', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018042, 'Muhammad Ichwan Anshory', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018043, 'Mira Novita Maharani', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018048, 'Muhammad Rizky Fauzi', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018049, 'Ade Darma Ariawan', 'Teknik Inomatika', 'Fakultas Teknologi Industri'),
(1400018050, 'M Yusu Wibisono', 'Teknik Inomatika', 'Fakultas Teknologi Industri');

-- --------------------------------------------------------

--
-- Struktur dari tabel `nilai_akhir`
--

CREATE TABLE `nilai_akhir` (
  `nim` varchar(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `pembimbing` int(100) NOT NULL,
  `penguji1` int(100) NOT NULL,
  `penguji2` int(100) NOT NULL,
  `total` int(100) NOT NULL,
  `huruf` varchar(2) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `nilai_pembimbing`
--

CREATE TABLE `nilai_pembimbing` (
  `nim` varchar(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `pembimbing` varchar(15) NOT NULL,
  `aktivitas_sig` int(20) NOT NULL,
  `penguasaan_materi` int(35) NOT NULL,
  `penguasaan_software` int(35) NOT NULL,
  `kesesuaian_jadwal` int(10) NOT NULL,
  `total` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `nilai_pembimbing`
--

INSERT INTO `nilai_pembimbing` (`nim`, `nama`, `pembimbing`, `aktivitas_sig`, `penguasaan_materi`, `penguasaan_software`, `kesesuaian_jadwal`, `total`) VALUES
('1400018005', 'Herwin Wibowo', '60160863', 8, 29, 27, 7, 71),
('1400018006', 'Syaripudin Khairil Anwar', '0014107301', 10, 25, 27, 8, 70);

-- --------------------------------------------------------

--
-- Struktur dari tabel `nilai_penguji1`
--

CREATE TABLE `nilai_penguji1` (
  `nim` varchar(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `niy` varchar(15) NOT NULL,
  `penguasaan_materi` int(50) NOT NULL,
  `penguasaan_software` int(30) NOT NULL,
  `presentasi` int(20) NOT NULL,
  `total` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `nilai_penguji1`
--

INSERT INTO `nilai_penguji1` (`nim`, `nama`, `niy`, `penguasaan_materi`, `penguasaan_software`, `presentasi`, `total`) VALUES
('1400018001', 'Oktaviyanto Rizal Chang', '', 20, 30, 20, 70);

-- --------------------------------------------------------

--
-- Struktur dari tabel `nilai_penguji2`
--

CREATE TABLE `nilai_penguji2` (
  `nim` varchar(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `penguasaan_materi` int(50) NOT NULL,
  `penguasaan_software` int(30) NOT NULL,
  `presentasi` int(20) NOT NULL,
  `total` int(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

-- --------------------------------------------------------

--
-- Struktur dari tabel `pendadaran`
--

CREATE TABLE `pendadaran` (
  `nim` varchar(11) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `judul_skripsi` text NOT NULL,
  `tanggal_pendadaran` datetime NOT NULL,
  `dosen_pembimbing` varchar(50) NOT NULL,
  `niy_pembimbing` varchar(15) NOT NULL,
  `dosen_penguji1` varchar(50) NOT NULL,
  `niy_penguji1` varchar(15) NOT NULL,
  `dosen_penguji2` varchar(50) NOT NULL,
  `niy_penguji2` varchar(15) NOT NULL,
  `tempat_ujian` varchar(50) NOT NULL,
  `sig` double NOT NULL,
  `materi3` double NOT NULL,
  `software3` double NOT NULL,
  `jadwal` double NOT NULL,
  `total_pembimbing` double NOT NULL,
  `total3` double NOT NULL,
  `materi1` double NOT NULL,
  `software1` double NOT NULL,
  `presentasi1` double NOT NULL,
  `total_penguji1` double NOT NULL,
  `total1` double NOT NULL,
  `materi2` double NOT NULL,
  `software2` double NOT NULL,
  `presentasi2` double NOT NULL,
  `total_penguji2` double NOT NULL,
  `total2` double NOT NULL,
  `total_na` double NOT NULL,
  `total_huruf` varchar(3) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pendadaran`
--

INSERT INTO `pendadaran` (`nim`, `nama`, `judul_skripsi`, `tanggal_pendadaran`, `dosen_pembimbing`, `niy_pembimbing`, `dosen_penguji1`, `niy_penguji1`, `dosen_penguji2`, `niy_penguji2`, `tempat_ujian`, `sig`, `materi3`, `software3`, `jadwal`, `total_pembimbing`, `total3`, `materi1`, `software1`, `presentasi1`, `total_penguji1`, `total1`, `materi2`, `software2`, `presentasi2`, `total_penguji2`, `total2`, `total_na`, `total_huruf`) VALUES
('1300018015', 'Harbiyana Uyun Maruf', 'judul skripsi kesekian', '2016-11-29 01:22:00', 'Adhi Prahara, S.Si., M.Cs.', '060150841', 'Eko Aribowo, S.T., M.Kom', '0006027001', 'Ali Tarmuji, S.T., M. Cs', '0014107301', 'Auditorium', 20, 20, 31, 8, 79, 39.5, 2, 2, 2, 6, 1.5, 45, 1, 1, 47, 11.75, 51, 'D'),
('1400018001', 'Oktaviyanto Rizal Chang', 'judul skripsi 1', '2016-11-12 01:17:00', 'Adhi Prahara, S.Si., M.Cs.', '060150841', 'Eko Aribowo, S.T., M.Kom', '0006027001', 'Ali Tarmuji, S.T., M. Cs', '0014107301', 'Lab Lantai 2', 12, 23, 34, 7, 76, 38, 12, 12, 12, 36, 9, 50, 30, 20, 100, 25, 72, 'B+'),
('1400018003', 'Aji Puwariyanto', 'judul1', '2016-11-16 12:46:00', 'Eko Aribowo, S.T., M.Kom', '0006027001', 'Adhi Prahara, S.Si., M.Cs.', '060150841', 'Ali Tarmuji, S.T., M. Cs', '0014107301', 'Ruang Prodi', 0, 0, 0, 0, 0, 0, 50, 30, 12, 92, 23, 0, 0, 0, 0, 0, 23, 'D'),
('1400018004', 'Dimas Wahyu Pribadi', 'judul skripsi 1', '2016-12-08 12:53:00', 'Eko Aribowo, S.T., M.Kom', '0006027001', 'Adhi Prahara, S.Si., M.Cs.', '060150841', 'Ali Tarmuji, S.T., M. Cs', '0014107301', 'Ruang Prodi', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
('1400018005', 'Herwin Wibowo', 'judul skripsi kesekian', '2016-11-16 12:55:00', 'Ali Tarmuji, S.T., M. Cs', '0014107301	', 'Ardiansyah, S.T., M. Cs', '60030476', 'Eko Aribowo, S.T., M.Kom', '0006027001', 'Lab Lantai 2', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
('1400018006', 'Syaripudin Khairil Anwar', 'judul1', '2016-11-15 12:58:00', 'Ardiansyah, S.T., M. Cs', '60030476', 'Ali Tarmuji, S.T., M. Cs', '0014107301', 'Adhi Prahara, S.Si., M.Cs.', '060150841', 'Ruang Prodi', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, ''),
('1400018008', 'Arimby Kusuma Wardani', 'judul', '2016-12-06 01:01:00', 'Farida Sulistyorini, S.T.', '0017107601', 'Herman Yuliansyah, S.T., M. Eng', '0512078304', 'Ardiansyah, S.T., M. Cs', '60030476', 'Auditorium', 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, 0, '');

-- --------------------------------------------------------

--
-- Struktur dari tabel `pengelola`
--

CREATE TABLE `pengelola` (
  `username` varchar(15) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `pengelola`
--

INSERT INTO `pengelola` (`username`, `password`, `nama`) VALUES
('0512078304', 'b445d3c82d2e52978e67c91f04cbb18e', 'Herman Yuliansyah, S.T., M. Eng');

-- --------------------------------------------------------

--
-- Struktur dari tabel `tb_kotaindonesia`
--

CREATE TABLE `tb_kotaindonesia` (
  `id` int(3) NOT NULL,
  `nama_kota` varchar(50) NOT NULL,
  `ibu_kota` varchar(50) NOT NULL,
  `keterangan` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `tb_kotaindonesia`
--

INSERT INTO `tb_kotaindonesia` (`id`, `nama_kota`, `ibu_kota`, `keterangan`) VALUES
(1, 'Medan', 'Medan', 'Kota Medan adalah ...\r\n'),
(2, 'Tapanuli Utara', 'Tarutung', 'Tapanuli Utara adalah ...'),
(3, 'Jakarta', 'jakarta', 'jakarta adalah ...'),
(4, 'Padang', 'padang', 'Padang adalah ...'),
(5, 'Deli Serdang', 'Lubuk Pakam', 'Deli Serdang adalah ...');

-- --------------------------------------------------------

--
-- Struktur dari tabel `ujian`
--

CREATE TABLE `ujian` (
  `no_ujian` int(100) NOT NULL,
  `nim` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL,
  `judul_skripsi` text NOT NULL,
  `tanggal_pendadaran` datetime NOT NULL,
  `dosen_pembimbing` varchar(50) NOT NULL,
  `niy_pembimbing` varchar(15) NOT NULL,
  `dosen_penguji1` varchar(40) NOT NULL,
  `niy_penguji1` varchar(15) NOT NULL,
  `dosen_penguji2` varchar(50) NOT NULL,
  `niy_penguji2` varchar(15) NOT NULL,
  `tempat_ujian` enum('Ruang Prodi','Lab Lantai 2','Auditorium') NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `ujian`
--

INSERT INTO `ujian` (`no_ujian`, `nim`, `nama`, `judul_skripsi`, `tanggal_pendadaran`, `dosen_pembimbing`, `niy_pembimbing`, `dosen_penguji1`, `niy_penguji1`, `dosen_penguji2`, `niy_penguji2`, `tempat_ujian`) VALUES
(1, '1400018004', 'Dimas Wahyu Pribadi', 'judul', '2016-11-02 05:05:00', 'Nur Rochmah Dyah Pujiastuti, S.T, M.Kom.', '0019087601', 'Rusydi Umar, S.T., M.T, Ph.D.', '0507087202	', 'Adhi Prahara, S.Si., M.Cs.', '060150841', 'Auditorium'),
(3, '1400018003', 'Aji Puwariyanto', 'judul 3', '2016-10-26 08:24:00', 'Eko Aribowo, S.T., M.Kom', '0006027001', 'Farida Sulistyorini, S.T.', '0017107601', 'Rusydi Umar, S.T., M.T, Ph.D.', '60980174', 'Ruang Prodi'),
(5, '1400018012', 'Mackands Leonardo Oktano', 'judul skripsi 1', '2016-11-03 07:40:00', 'Murinto, S.Si., M. Kom', '60040496', 'Dewi Soyusiawaty, S.T., M.T', '60040497', 'Sri Winiarti, S.T., M. Cs', '60020388', 'Lab Lantai 2'),
(6, '1400018036', 'Tegar Putra Kurniawan', 'judul skripsi kesekian', '2016-11-13 11:47:00', 'Eko Aribowo, S.T., M.Kom', '0006027001', 'Dewi Pramudi Ismi, S.T., M.CompSc', '060150842', 'Taufik Ismail, S.T., M. Cs', '60010314', 'Lab Lantai 2');

-- --------------------------------------------------------

--
-- Struktur dari tabel `user`
--

CREATE TABLE `user` (
  `username` varchar(15) NOT NULL,
  `password` varchar(50) NOT NULL,
  `nama` varchar(50) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data untuk tabel `user`
--

INSERT INTO `user` (`username`, `password`, `nama`) VALUES
('0006027001', 'f3d81083579c47da50c4116fce3b792e', 'Eko Aribowo, S.T., M.Kom'),
('0014107301', '083787688381e260ff962cbfd645c1fb', 'Ali Tarmuji, S.T., M. Cs'),
('0015118001', 'f1163db4fa5d133f619620d0d0d0a454', 'Fiftin Noviyanto, S.T., M. Cs'),
('0017107601', '1e836de451b2b16b5827026fa704e749', 'Farida Sulistyorini, S.T.'),
('0019087601', 'f70eb1da8444eac76f380f6c69080fae', 'Nur Rochmah Dyah Pujiastuti, S.T, M.Kom.'),
('0507087202', 'ca843fdd5ef7b4f23b346e799be593c1', 'Rusydi Umar, S.T., M.T, Ph.D.'),
('0512078304', 'b445d3c82d2e52978e67c91f04cbb18e', 'Herman Yuliansyah, S.T., M. Eng'),
('060150841', '12663c0d2ea1beaf71f636bd32d9b18e', 'Adhi Prahara, S.Si., M.Cs.'),
('060150842', '43c794ff372f7d85819689d15a09f881', 'Dewi Pramudi Ismi, S.T., M.CompSc'),
('60010308', '67d2686ea8c5ac969f95d5f642066d47', 'Sri Handayaningsih, S.T., M.T.'),
('60010314', 'f13c12ed97df829a1fd6b412793c023f', 'Taufik Ismail, S.T., M. Cs'),
('60020388', 'ce5c01a8c494bd37b51652760393063f', 'Sri Winiarti, S.T., M. Cs'),
('60030475', 'bcae97cf25d4b3f158b6c0c6e71f22df', 'Drs. Tedy Setiadi, M.T'),
('60030476', '6754b0da8815529a08bb953c76cd17f6', 'Ardiansyah, S.T., M. Cs'),
('60030479', '62a329390d888043e834781a96ea5f27', 'Muhammad Aziz, S.T., M. Cs'),
('60030480', 'f9044bd15c5a49b9108822916bcfa0aa', 'Ir. Ardi Pujiyanta, M. T.'),
('60040496', '72178295a8e1844cebd9b3a8129a4225', 'Murinto, S.Si., M. Kom'),
('60040497', '941e434759e1f87add2ec940f67f959f', 'Dewi Soyusiawaty, S.T., M.T'),
('60090586', '9d5f2b29790d204d6a77509241b323ee', 'Arfiani Nur Khusna, S.T., M.Kom.'),
('60090587', '49d857b578fa7d9597346954b2b9921f', 'Lisna Zahrotun S.T.'),
('60110647', '941c63141b5cf0d50e8a42cda474c5c8', 'Anna Hendri Soleliza Jones, S. Kom'),
('60130756', '7e7e0c2a3fa90b41e0745bfbecf8c34c', 'Yana Hendriana, S.T., M.Eng.'),
('60130757', '7cc9d4500255f276caabc5a0e80b199a', 'Andri Pranolo, S.Kom., M. Cs'),
('60160863', '90152da42d9741df02be8fde79cec2a7', 'Ahmad Azhari, S.Kom., M.Eng.'),
('60160865', '704072eebf8f81702415ea72dd79ea62', 'Widhia Oktoeberza KZ., S.T., M.Eng.'),
('60160952', 'adccb3c0367ec783f0cc94c007116609', 'Supriyanto, S.T., M.T.'),
('60160978', '8c044253060f76a87b296a4a2bfb8324', 'Dwi Normawati, S.T., M.Eng.'),
('60160979', 'fca895c14f69b996d816c76090506707', 'Jefree Fahana, ST., M.Kom.'),
('60160980', 'd759e2d9ff1bc32b7b8eefcf21e7d562', 'Nuril Anwar, S.T.,M.Kom'),
('60910095', '642506a7cb7d41fe7a058964dc3f2620', 'Drs. Wahyu Pujiyono, M. Kom'),
('60960147', '4ffbe2646f7790843e064c1d7a42eb5b', 'Mushlihudin, S.T., M.T.');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `dosen`
--
ALTER TABLE `dosen`
  ADD PRIMARY KEY (`niy`);

--
-- Indexes for table `mhs`
--
ALTER TABLE `mhs`
  ADD PRIMARY KEY (`nim`);

--
-- Indexes for table `nilai_akhir`
--
ALTER TABLE `nilai_akhir`
  ADD PRIMARY KEY (`nim`);

--
-- Indexes for table `nilai_pembimbing`
--
ALTER TABLE `nilai_pembimbing`
  ADD PRIMARY KEY (`nim`);

--
-- Indexes for table `nilai_penguji1`
--
ALTER TABLE `nilai_penguji1`
  ADD PRIMARY KEY (`nim`);

--
-- Indexes for table `nilai_penguji2`
--
ALTER TABLE `nilai_penguji2`
  ADD PRIMARY KEY (`nim`);

--
-- Indexes for table `pendadaran`
--
ALTER TABLE `pendadaran`
  ADD PRIMARY KEY (`nim`);

--
-- Indexes for table `pengelola`
--
ALTER TABLE `pengelola`
  ADD PRIMARY KEY (`username`);

--
-- Indexes for table `tb_kotaindonesia`
--
ALTER TABLE `tb_kotaindonesia`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `ujian`
--
ALTER TABLE `ujian`
  ADD PRIMARY KEY (`no_ujian`),
  ADD KEY `nim` (`nim`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `tb_kotaindonesia`
--
ALTER TABLE `tb_kotaindonesia`
  MODIFY `id` int(3) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=6;
--
-- AUTO_INCREMENT for table `ujian`
--
ALTER TABLE `ujian`
  MODIFY `no_ujian` int(100) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=7;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
