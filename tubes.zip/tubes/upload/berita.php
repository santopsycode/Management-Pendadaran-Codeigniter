<html>
<head>
<title>UPDATE BERITA</title>
<link type="text/css" rel="stylesheet" href="style2.css"/>
</head>
<body>
<div id="wrapper">
	<div id="header">
    <h1 align="center">Update Berita
	</h1>
    </div>          
    <div id="wrapper_konten">
		
		<div id="right_konten">
		<?php
            // Connect to Database
		    mysql_connect("localhost", "root", "");
		    mysql_select_db("db_tubes");

            $kueri = mysql_query(" SELECT * FROM dosen");
            while ($baris=mysql_fetch_array($kueri))
            {
             //echo $baris['Waktu'];
             //$date = DateTime::createFromFormat('Y-m-d', $baris["Waktu"]);
             //echo htmlspecialchars($date->format('F Y'), ENT_QUOTES, "UTF-8");

             
             echo "<br>";
             echo "Judul :".$baris['niy']."<br><br>";
             echo "nama :".$baris['nama']."<br><br>";
             echo "<img src=../assets/image/".$baris['foto'].">";
             echo"<br><br><hr>";
            }
        ?>
        </div>
		<div id="right_konten_bottom">  			
        </div>
    </div>
</div>
</body>
</html>