<?php
// Connect to Database
mysql_connect("localhost", "root", "");
mysql_select_db("db_tubes");

$niy=$_POST['niy'];
$nama=$_POST['nama'];
//$tgl= date('d-M-Y H:i:s');
$tgl = date('Y-m-d H:i:s');
//echo $tgl.$judu;

if (isset($_POST['simpan'])){
	$fileName = $_FILES['image']['name'];

    // Simpan ke Database
	$sql = "insert into dosen Values ('$niy', '$nama', '$fileName')";
	mysql_query($sql);
	// Simpan di Folder Gambar
	move_uploaded_file($_FILES['image']['tmp_name'], "../assets/image/".$_FILES['image']['name']);
	echo"<script>alert('Gambar Berhasil diupload !');history.go(-1);</script>";
}

?>