<html>
<head>
<title>Uploap Image to Database </title>
<link type="text/css" rel="stylesheet" href="style.css"/>
<script type="text/javascript">

				function PreviewImage() {
				var oFReader = new FileReader();
				oFReader.readAsDataURL(document.getElementById("uploadImage").files[0]);

				oFReader.onload = function (oFREvent) {
				document.getElementById("uploadPreview").src = oFREvent.target.result;
				};
				};

				</script>
</head>
<body>
<div id="wrapper">
	<div id="header">
    <h1 align="center">Upload Image
	<br>To Database
	</h1>
    </div>          
    <div id="wrapper_konten">
		<div id="left_konten">
        <nav>
        <ul>
            <li><a href="#">Input</a>
            <li><a href="berita.php">Tampilkan</a>
        </ul>
        </nav>
        <img src="image/logo.jpg" style="padding-left: 20px; padding-top: 280px"  />
        </div>
		<div id="right_konten">
			<div id="form_top_artikel"> </div>
			<div id="form_content_artikel">
				<div id="isi_artikel">
				<form name="visi" method="post" action="posting.php" enctype="multipart/form-data">
					niy <input type="text" name="niy"><br>
					nama <input type="text" name="nama">
					Gambar<br>
					<img id="uploadPreview" style="width: 150px; height: 150px;" /><br>
					<input id="uploadImage" type="file" name="image" onchange="PreviewImage();" />
					<br><br>
					<input type="submit" width="120" height="24" name="simpan" value="Submit" >
				</form>
				</div>
			</div>
			<div id="form_bottom_artikel">
			<a href="http://ilmu-detil.blogspot.com">
			<div class="produksi">Pusat Ilmu Secara Detil</div>
			</a>
			</div>
        </div>
	 </div>
</div>
</body>
</html>