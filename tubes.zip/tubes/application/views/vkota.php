<!DOCTYPE html>
<html lang="">
    <head>
        <meta charset="utf-8">
        <meta http-equiv="X-UA-Compatible" content="IE=edge">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>Title Page</title>

        <!-- Bootstrap CSS -->
        <!-- <link rel="stylesheet" href="<?php echo base_url(); ?>assets/css/bootstrap.min.css" > -->

        <!-- Materialize CSS -->
        <link rel="stylesheet" href="<?php echo base_url(); ?>assets/materialize/css/materialize.css" >

        <style type="text/css">
          .parallax-container {
            height: 300px;
          }
        </style>
    </head>
    <body>

        <div class="parallax-container">
          <div class="parallax"><img src="<?php echo base_url(); ?>assets/img/1.jpg"></div>
        </div>
        <h1 class="text-center">Hello World</h1>
        <form class="formValidate" id="formValidate">
            
            <div class="row">
              <form class="col s12">
                <div class="row">
                  <div class="input-field col s6">
                    <input placeholder="Placeholder" id="first_name" type="text" class="validate">
                    <label for="first_name">First Name</label>
                  </div>
                  <div class="input-field col s6">
                    <input id="last_name" type="text" class="validate">
                    <label for="last_name">Last Name</label>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field col s12">
                    <input disabled value="I am not editable" id="disabled" type="text" class="validate">
                    <label for="disabled">Disabled</label>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field col s12">
                    <input id="password" type="password" class="validate">
                    <label for="password">Password</label>
                  </div>
                </div>
                <div class="row">
                  <div class="input-field col s12">
                    <input id="email" type="email" class="validate">
                    <label for="email" data-error="SALAH CUK !!  kudu enek '@' conto koe@jancok.su" data-success="right">Email</label>
                  </div>
                </div>
                <div class="row">
                  <div class="col s12">
                    This is an inline input field:
                    <div class="input-field inline">
                      <input id="email" type="email" class="validate">
                      <label for="email" data-error="SALAH CUK !!  kudu enek '@' conto koe@jancok.su" data-success="right">Email</label>
                    </div>
                  </div>
                </div>
              </form>
            </div>

        </form>

        <script type="text/javascript">
          $("#formValidate").validate({
              rules: {
                  last_name: {
                      required: true,
                      minlength: 5
                  },
                  cemail: {
                      required: true,
                      email:true
                  },
                  password: {
                      required: true,
                      minlength: 5
                  },
                  cpassword: {
                      required: true,
                      minlength: 5,
                      equalTo: "#password"
                  },
                  curl: {
                      required: true,
                      url:true
                  },
                  crole:"required",
                  ccomment: {
                      required: true,
                      minlength: 15
                  },
                  cgender:"required",
                  cagree:"required",
              },
              //For custom messages
              messages: {
                  last_name:{
                      required: "Enter a username",
                      minlength: "Enter at least 5 characters"
                  },
                  curl: "Enter your website",
              },
              errorElement : 'div',
              errorPlacement: function(error, element) {
                var placement = $(element).data('error');
                if (placement) {
                  $(placement).append(error)
                } else {
                  error.insertAfter(element);
                }
              }
           });
        </script>

        <!-- jQuery -->
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/js/jquery.min.js"></script>
        <script type="text/javascript" src="<?php echo base_url(); ?>assets/materialize/js/materialize.min.js"></script>
    </body>
</html>