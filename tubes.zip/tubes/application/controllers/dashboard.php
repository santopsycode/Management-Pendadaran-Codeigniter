<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Dashboard extends CI_Controller {

	function __construct(){

		parent::__construct();
		if($this->session->userdata('status') != "login"){
			redirect('login');
		}
		$this->load->library('session');
		$this->load->model('mymodel');
 		
		$id = $this->session->userdata("username");

	}

	public function index()
	{

		$id 			= $this->session->userdata("username");				
		$isi['user']	= $this->db->query("SELECT nama FROM user WHERE username='$id'");
		$isi['content'] = 'content/cdashboard';
		$isi['judul'] 	='<li>Dashboard</li>';
	    $isi['usr']= $this->db->get('user');
		$this->load->view('layout/ldashboard',$isi);

	}

	public function logout()
	{

		$this->session->sess_destroy();
		redirect('home');

	}

	public function penguji1()
	{
		$key	= $this->uri->segment(3);
		$this->db->where('nim',$key);
		$query	= $this->db->get('pendadaran');

		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row)
			{

				$isi['nim']					=$row->nim;
				$isi['nama']				=$row->nama;
				$isi['sig']					=$row->sig;
				$isi['materi3']				=$row->materi3;
				$isi['software3']			=$row->software3;
				$isi['jadwal']				=$row->jadwal;
				$isi['total_pembimbing']	=$row->total_pembimbing;
				$isi['total1']				=$row->total1;
				$isi['total2']				=$row->total2;
				$isi['total3']				=$row->total3;
				$isi['total_na']			=$row->total_na;
				$isi['total_huruf']			=$row->total_huruf;

			}
		}
		else
		{

		$isi['nim']					='';	
		$isi['nama']				='';	
		$isi['sig']					='';	
		$isi['materi3']				='';	
		$isi['software3']			='';	
		$isi['jadwal']				='';	
		$isi['total_pembimbing']	='';	
		$isi['total1']				='';	
		$isi['total2']				='';	
		$isi['total3']				='';	
		$isi['total_na']			='';	
		$isi['total_huruf']			='';	

		}


		$id 			= $this->session->userdata("username");				
		$isi['user']	= $this->db->query("SELECT nama FROM user WHERE username='$id'");
		$isi['content'] = 'content/cpenguji1';
		$isi['judul'] 	='<li><a href="http://localhost/tubes/index.php/dashboard">Dashboard</a></li>
						  <li>Nilai Penguji 1</li>';
	    $isi['data']	= $this->db->query("SELECT * FROM pendadaran WHERE niy_penguji1='$id'");
		$this->load->view('layout/ldashboard',$isi);

	}

	public function updatePenguji1()
	{

		$id 				= $this->session->userdata("username");
		$isi['user']		= $this->db->query("SELECT nama FROM user WHERE username='$id'");
		$isi['content'] 	= 'content/form/form_nilai_penguji1';
		$isi['input']		= 'readonly';
		$isi['judul'] 		='<li><a href="http://localhost/tubes/index.php/dashboard">Dashboard</a></li>
						  		<li><a href="http://localhost/tubes/index.php/dashboard/penguji1">Nilai Penguji 1</a></li>
						  		<li>Input Nilai</li>';

		$key	= $this->uri->segment(3);
		$this->db->where('nim',$key);
		$query	= $this->db->get('pendadaran');

		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row)
			{

				$isi['nim']					=$row->nim;
				$isi['nama']				=$row->nama;
				$isi['materi1']				=$row->materi1;
				$isi['software1']			=$row->software1;
				$isi['presentasi1']			=$row->presentasi1;
				$isi['total_penguji1']		=$row->total_penguji1;
				$isi['total1']				=$row->total1;
				$isi['total2']				=$row->total2;
				$isi['total3']				=$row->total3;
				$isi['total_na']			=$row->total_na;
				$isi['total_huruf']			=$row->total_huruf;

			}
		}
		else
		{

		$isi['nim']					='';	
		$isi['nama']				='';	
		$isi['materi1']				='';	
		$isi['software1']			='';	
		$isi['presentasi1']			='';	
		$isi['total_penguji1']		='';	
		$isi['total1']				='';	
		$isi['total2']				='';	
		$isi['total3']				='';	
		$isi['total_na']			='';	
		$isi['total_huruf']			='';	

		}

		$this->load->view('layout/ldashboard',$isi);

	}

	public function simpanPenguji1()
	{

		$key 							= $this->input->post('nim');
		$data['nim'] 					= $this->input->post('nim');
		$data['nama'] 					= $this->input->post('nama');
		$data['materi1'] 				= $this->input->post('materi1');
		$data['software1'] 				= $this->input->post('software1');
		$data['presentasi1'] 			= $this->input->post('presentasi1');
		$data['total_penguji1'] 		= $this->input->post('total_penguji1');
		$data['total1'] 				= $this->input->post('total1');
		$data['total2'] 				= $this->input->post('total2');
		$data['total3'] 				= $this->input->post('total3');
		$data['total_na'] 				= $this->input->post('total_na');
		$data['total_huruf'] 			= $this->input->post('total_huruf');

		$query = $this->mymodel->getDataPembimbing($key);
		if($query->num_rows()>0)
		{
			$this->mymodel->getUpdatePembimbing($key,$data);
			$this->session->set_flashdata('info','Data berhasil disimpan');
		}
		else
		{
			$this->mymodel->getInsertPembimbing($data);
			$this->session->set_flashdata('info','Data berhasil ditambah');
		}
		redirect('dashboard/penguji1');

	}

	public function penguji2()
	{

		$id 			= $this->session->userdata("username");				
		$isi['user']	= $this->db->query("SELECT nama FROM user WHERE username='$id'");
		$isi['content'] = 'content/cpenguji2';
		$isi['judul'] 	='<li><a href="http://localhost/tubes/index.php/dashboard">Dashboard</a></li>
						  <li>Nilai Penguji 2</li>';
	    $isi['data']	= $this->db->query("SELECT * FROM pendadaran WHERE niy_penguji2='$id'");
		$this->load->view('layout/ldashboard',$isi);

	}

	public function updatePenguji2()
	{

		$id 				= $this->session->userdata("username");
		$isi['user']		= $this->db->query("SELECT nama FROM user WHERE username='$id'");
		$isi['content'] 	= 'content/form/form_nilai_penguji2';
		$isi['input']		= 'readonly';
		$isi['judul'] 		='<li><a href="http://localhost/tubes/index.php/dashboard">Dashboard</a></li>
						  		<li><a href="http://localhost/tubes/index.php/dashboard/pembimbing">Nilai Pembiming</a></li>
						  		<li>Input Nilai</li>';

		$key	= $this->uri->segment(3);
		$this->db->where('nim',$key);
		$query	= $this->db->get('pendadaran');

		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row)
			{

				$isi['nim']					=$row->nim;
				$isi['nama']				=$row->nama;
				$isi['materi2']				=$row->materi2;
				$isi['software2']			=$row->software2;
				$isi['presentasi2']			=$row->presentasi2;
				$isi['total_penguji2']		=$row->total_penguji2;
				$isi['total1']				=$row->total1;
				$isi['total2']				=$row->total2;
				$isi['total3']				=$row->total3;
				$isi['total_na']			=$row->total_na;
				$isi['total_huruf']			=$row->total_huruf;

			}
		}
		else
		{

		$isi['nim']					='';	
		$isi['nama']				='';	
		$isi['materi2']				='';	
		$isi['software2']			='';	
		$isi['presentasi2']			='';	
		$isi['total_penguji2']		='';	
		$isi['total1']				='';	
		$isi['total2']				='';	
		$isi['total3']				='';	
		$isi['total_na']			='';	
		$isi['total_huruf']			='';	

		}

		$this->load->view('layout/ldashboard',$isi);

	}

	public function simpanPenguji2()
	{

		$key 							= $this->input->post('nim');
		$data['nim'] 					= $this->input->post('nim');
		$data['nama'] 					= $this->input->post('nama');
		$data['materi2'] 				= $this->input->post('materi2');
		$data['software2'] 				= $this->input->post('software2');
		$data['presentasi2'] 			= $this->input->post('presentasi2');
		$data['total_penguji2'] 		= $this->input->post('total_penguji2');
		$data['total1'] 				= $this->input->post('total1');
		$data['total2'] 				= $this->input->post('total2');
		$data['total3'] 				= $this->input->post('total3');
		$data['total_na'] 				= $this->input->post('total_na');
		$data['total_huruf'] 			= $this->input->post('total_huruf');

		$query = $this->mymodel->getDataPembimbing($key);
		if($query->num_rows()>0)
		{
			$this->mymodel->getUpdatePembimbing($key,$data);
			$this->session->set_flashdata('info','Data berhasil disimpan');
		}
		else
		{
			$this->mymodel->getInsertPembimbing($data);
			$this->session->set_flashdata('info','Data berhasil ditambah');
		}
		redirect('dashboard/penguji2');

	}

	public function pembimbing()
	{

		$id 			= $this->session->userdata("username");
		$isi['user']	= $this->db->query("SELECT nama FROM user WHERE username='$id'");
		$isi['content'] = 'content/cpembimbing';
		$isi['judul'] 	='<li><a href="http://localhost/tubes/index.php/dashboard">Dashboard</a></li>
						  <li>Nilai Pembiming</li>';
		$isi['data']	= $this->db->query("SELECT * FROM pendadaran WHERE niy_pembimbing='$id'");
		$this->load->view('layout/ldashboard',$isi);
	}

	public function tambahPembimbing()
	{

		$id 			= $this->session->userdata("username");
		$isi['user']	= $this->db->query("SELECT nama FROM user WHERE username='$id'");
		$isi['content'] = 'content/form/form_nilai_pembimbing';
		$isi['input']	= '';
		$isi['judul'] 	='<li><a href="http://localhost/tubes/index.php/dashboard">Dashboard</a></li>
						  <li><a href="http://localhost/tubes/index.php/dashboard/pembimbing">Nilai Pembiming</a></li>
						  <li>Input Nilai</li>';

		$isi['nim']						='';	
		$isi['nama']					='';	
		$isi['pembimbing']				='';	
		$isi['sig']						='';	
		$isi['materi3']					='';	
		$isi['software3']				='';	
		$isi['jadwal']					='';	
		$isi['total_pembimbing']		='';
		$isi['total3']					='';

		$this->load->view('layout/ldashboard',$isi);

	}

	public function updatePembimbing()
	{

		$id 				= $this->session->userdata("username");
		$isi['user']		= $this->db->query("SELECT nama FROM user WHERE username='$id'");
		$isi['content'] 	= 'content/form/form_nilai_pembimbing';
		$isi['input']		= 'readonly';
		$isi['judul'] 		='<li><a href="http://localhost/tubes/index.php/dashboard">Dashboard</a></li>
						  		<li><a href="http://localhost/tubes/index.php/dashboard/pembimbing">Nilai Pembiming</a></li>
						  		<li>Input Nilai</li>';

		$key	= $this->uri->segment(3);
		$this->db->where('nim',$key);
		$query	= $this->db->get('pendadaran');

		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row)
			{

				$isi['nim']					=$row->nim;
				$isi['nama']				=$row->nama;
				$isi['sig']					=$row->sig;
				$isi['materi3']				=$row->materi3;
				$isi['software3']			=$row->software3;
				$isi['jadwal']				=$row->jadwal;
				$isi['total_pembimbing']	=$row->total_pembimbing;
				$isi['total1']				=$row->total1;
				$isi['total2']				=$row->total2;
				$isi['total3']				=$row->total3;
				$isi['total_na']			=$row->total_na;
				$isi['total_huruf']			=$row->total_huruf;

			}
		}
		else
		{

		$isi['nim']					='';	
		$isi['nama']				='';	
		$isi['sig']					='';	
		$isi['materi3']				='';	
		$isi['software3']			='';	
		$isi['jadwal']				='';	
		$isi['total_pembimbing']	='';	
		$isi['total1']				='';	
		$isi['total2']				='';	
		$isi['total3']				='';	
		$isi['total_na']			='';	
		$isi['total_huruf']			='';	

		}

		$this->load->view('layout/ldashboard',$isi);

	}

	public function simpanPembimbing()
	{

		$key 							= $this->input->post('nim');
		$data['nim'] 					= $this->input->post('nim');
		$data['nama'] 					= $this->input->post('nama');
		$data['sig'] 					= $this->input->post('sig');
		$data['materi3'] 				= $this->input->post('materi3');
		$data['software3'] 				= $this->input->post('software3');
		$data['jadwal'] 				= $this->input->post('jadwal');
		$data['total_pembimbing'] 		= $this->input->post('total_pembimbing');
		$data['total1'] 				= $this->input->post('total1');
		$data['total2'] 				= $this->input->post('total2');
		$data['total3'] 				= $this->input->post('total3');
		$data['total_na'] 				= $this->input->post('total_na');
		$data['total_huruf'] 			= $this->input->post('total_huruf');

		$query = $this->mymodel->getDataPembimbing($key);
		if($query->num_rows()>0)
		{
			$this->mymodel->getUpdatePembimbing($key,$data);
			$this->session->set_flashdata('info','Data berhasil disimpan');
		}
		else
		{
			$this->mymodel->getInsertPembimbing($data);
			$this->session->set_flashdata('info','Data berhasil ditambah');
		}
		redirect('dashboard/pembimbing');

	}


	public function deletePenguji1()
	{
		$key	= $this->uri->segment(3);
		$this->db->where('nim',$key);
		$query	= $this->db->get('pendadaran');

		if($query->num_rows()>0)
		{
			foreach ($query->result() as $row)
			{

				$isi['nim']					=$row->nim;
				$isi['nama']				=$row->nama;
				$isi['materi1']				=$row->materi1;
				$isi['software1']			=$row->software1;
				$isi['presentasi1']			=$row->presentasi1;
				$isi['total_penguji1']		=$row->total_penguji1;
				$isi['total1']				=$row->total1;
				$isi['total2']				=$row->total2;
				$isi['total3']				=$row->total3;
				$isi['total_na']			=$row->total_na;
				$isi['total_huruf']			=$row->total_huruf;

			}
		}
		else
		{

		$isi['nim']					='';	
		$isi['nama']				='';	
		$isi['materi1']				='';	
		$isi['software1']			='';	
		$isi['presentasi1']			='';	
		$isi['total_penguji1']		='';	
		$isi['total1']				='';	
		$isi['total2']				='';	
		$isi['total3']				='';	
		$isi['total_na']			='';	
		$isi['total_huruf']			='';	

		}

		$this->db->query("UPDATE pendadaran SET materi1='0', software1='0', presentasi1='0',total_penguji1='0' WHERE nim='$key'");


		redirect('dashboard/penguji1');

	}

}
