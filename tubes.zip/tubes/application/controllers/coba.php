<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Coba extends CI_Controller {

		function __construct(){

			parent::__construct();
			if($this->session->userdata('status') != "login"){
				redirect('login');
			}
			$this->load->model('mcoba');
			$this->load->helper(array('url')); //load helper url
	 		
		}

		/*public function index()
			{
				$data['titel']=''; //varibel title
        		$this->load->view('vkota',$data); //tampilan awal ketika controller kota di akses

			}*/

			
		public function index()
			{
				$data['titel']=''; //varibel title
        		$this->load->view('vkota',$data); //tampilan awal ketika controller kota di akses

			}

		public function get_mhs() {
			$$this->load->model('mcoba');
	        $kode 	= $this->input->post('nim',TRUE); //variabel kunci yang di bawa dari input text id kode
	        $query 	= $this->mcoba->get_mhs(); //query model
	 
	        $kota       		=  array();
	        foreach ($query->result() as $d) {
	            $kota[]     		= array(
	                'label' 		=> $d->nim, //variabel array yg dibawa ke label ketikan kunci
	                'nim' 			=> $d->nim , //variabel yg dibawa ke id nama
	                'nama' 			=> $d->nama
	            );
	        }
	        echo json_encode($kota);      //data array yang telah kota deklarasikan dibawa menggunakan json
	    }

		    public function view()
		    {
		        $data['base'] = $this->config->base_url();

		        //FOR THE TITLE PART
		        $data['title'] = ucfirst('Test'); 

		        $this->load->view('templates/header', $data);
		    }

		    public function posts(){ // akses fungtion getAllPost didalam class (model) post
				$this->load->view('layout/ldashboard',$data); //load view vpost dan kirimkan data dalam bentuk objek $data
			}

			public function datamhs()
		    {
		    	$this->load->model('mcoba');

			    $nim        = $_GET['nim'];
			    $query      = $this->db->mysql_query('select * from mhs where nim=$nim');
			    $mhs        = mysql_fetch_array($query);
			    $nama_mhs   = array('nama_lengkap' => $mhs['nama_lenkap'],);

			    echo json_encode($nama_mhs);

		    }

}