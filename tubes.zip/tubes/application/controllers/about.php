<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class About extends CI_Controller {


	public function index()
	{
		$isi['content'] = 'content/cabout';
		$this->load->view('layout/lhome',$isi);
	}

	public function logout()
	{
		$this->session->sess_destroy();
		redirect('home');
	}

}

/* End of file welcome.php */
/* Location: ./application/controllers/welcome.php */