<?php
defined('BASEPATH') OR exit('No direct script access allowed');

class Auto extends CI_Controller {
 public function __construct()
 {
  parent::__construct();
  $this->load->model('mdb');
 }
 public function index()
 {
 	$this->load->model('mdb');

 	$nim 	= $this->input->get('nim');
 	$query	=$this->db->query("SELECT * FROM mhs WHERE nim='$nim'")->result();
	   $data=array();
	   $i=0;
	   foreach($query as $r){
	    $data[$i]['nim']		=	$r->nim;
	    $data[$i]['nama']		=	$r->nama;
	    $data[$i]['prodi']		=	$r->prodi;
	    $data[$i]['fakultas']	=	$r->fakultas;
	    $i++;
	   }
	   echo json_encode($data);

  $this->load->view('auto');
 }
 
 public function mhs()
 {
 	
 }

}