<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Mymodel extends CI_Model {

	function cek_login($table,$where){		
		$d = $this->db->get_where($table,$where);
		return $d;
	}

	public function getDataPembimbing($key)
	{

		$this->db->where('nim',$key);
		$hasil 		= $this->db->get ('pendadaran');
		return $hasil;

	}


	public function getUpdatePembimbing($key,$data)
		{

			$this->db->where('nim',$key);
			$this->db->update('pendadaran',$data);

		}

	public function getInsertPembimbing($data)
	{

		$this->db->insert('pendadaran',$data);

	}

	public function getDeletePembimbing($nim)
	{

		$this->db->get_where('nim',$nim);
		$this->db->query("UPDATE pendadaran SET total_pembimbing='0' WHERE nim='$nim'");

	}

}
