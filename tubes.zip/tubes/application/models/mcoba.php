<?php if ( ! defined('BASEPATH')) exit('No direct script access allowed');

class Mcoba extends CI_Controller {

    var $tabel = 'mhs';   //variabel tabelnya
 
    function __construct() {
        parent::__construct();
    }
 
    //fungsi untuk menampilkan semua data dari tabel database
    function get_mhs() {
        $this->db->from($this->tabel);
        $query = $this->db->get();
 
        //cek apakah ada data
        if ($query->num_rows() > 0) { //jika ada maka jalankan
            return $query->result();
        }
    }

	public function getdata($key)
	{
		$this->db->where('nim',$key);
		$hasil = $this->db->get ('mhs');
	}

    function search_post($str){

        $this->db->where('nim',$str);
        $query=$this->db->query("SELECT nama FROM mhs WHERE nim='$str'");
        return $query->result();
    //in this tutourial i have 3 table to join but you can use your table
    //to get data by yourself depend on you need 
    }


    public function check_event($test_input)
    {
        if($test_input==null){
            return "True";
        }
        else
            return "False";
    }


}